import pool from './db.js';
import crypto from 'crypto';

const createResponse = (statusCode, body) => ({
    statusCode,
    headers: { "Access-Control-Allow-Origin": "*", "Content-Type": "application/json" },
    body: JSON.stringify(body),
});

export const handler = async (event) => {
    const httpMethod = event.httpMethod || event.requestContext?.httpMethod;
    const managerId = event.pathParameters?.managerId;
    const status = event.queryStringParameters?.status;

    const tenantId = '79c00000-0000-0000-0000-000000000001';
    if (!managerId) return createResponse(400, { message: "Manager ID required" });

    let client;
    try {
        client = await pool.connect();

        if (httpMethod === 'GET' && status) {
            const page = event.queryStringParameters?.page;
            const limit = event.queryStringParameters?.limit;

            const baseQuery = `
                SELECT
                    r.id,
                    r.employee_id,
                    e.name AS employee_name,
                    e.role,
                    e.avatar_url,
                    r.start_date,
                    r.end_date,
                    r.type,
                    r.status,
                    r.source,
                    r.reason,
                    r.total_days,
                    r.created_at
                FROM (
                    SELECT 
                        id, employee_id, start_date, end_date, type, status, 'leave' AS source, reason, total_days, created_at
                    FROM leaves
                    WHERE status <> 'Pending' AND manager_id = $1 AND tenant_id = $2
                    UNION ALL
                    SELECT 
                        id, employee_id, start_date, end_date, type, status, 'compoff' AS source, reason, NULL as total_days, created_at
                    FROM attendance
                    WHERE status <> 'Pending' AND type = 'compoff' AND manager_id = $1 AND tenant_id = $2
                    UNION ALL
                    SELECT 
                        id, employee_id, start_date, end_date, type, status, 'attendance' AS source, reason, total_days, created_at
                    FROM attendance
                    WHERE status <> 'Pending' AND type = 'general attendance' AND manager_id = $1 AND tenant_id = $2
                ) r
                JOIN employees e ON e.employee_id = r.employee_id
            `;

            if (page && limit) {
                const pageNum = parseInt(page);
                const limitNum = parseInt(limit);
                const offset = (pageNum - 1) * limitNum;

                // Count Query (Correct me if this is expensive, but for now this works)
                // Wrapping the whole logic is safest for consistent results count.
                // However, I can just count the unions.
                // Simplified count query:
                const countQuery = `
                    SELECT COUNT(*) as count FROM (
                        SELECT id FROM leaves WHERE status <> 'Pending' AND manager_id = $1 AND tenant_id = $2
                        UNION ALL
                        SELECT id FROM attendance WHERE status <> 'Pending' AND type = 'compoff' AND manager_id = $1 AND tenant_id = $2
                        UNION ALL
                        SELECT id FROM attendance WHERE status <> 'Pending' AND type = 'general attendance' AND manager_id = $1 AND tenant_id = $2
                    ) sub
                `;

                const countRes = await client.query(countQuery, [managerId, tenantId]);
                const total = parseInt(countRes.rows[0].count);
                const totalPages = Math.ceil(total / limitNum);

                const finalQuery = `${baseQuery} ORDER BY r.start_date DESC LIMIT $3 OFFSET $4`;
                const res = await client.query(finalQuery, [managerId, tenantId, limitNum, offset]);

                return createResponse(200, {
                    data: res.rows,
                    meta: {
                        total,
                        page: pageNum,
                        limit: limitNum,
                        totalPages
                    }
                });
            }

            // Default (Legacy)
            const query = `${baseQuery} ORDER BY r.start_date DESC`;
            const res = await client.query(query, [managerId, tenantId]);
            return createResponse(200, res.rows);
        }

        if (httpMethod === 'GET') {
            // Fetch items only for direct reports
            // Segregate: 'leave' = applying for leave, 'compoff_earning' = weekend work approval
            const query = `SELECT
                r.id,
                r.employee_id,
                e.name AS employee_name,
                e.role,
                e.avatar_url,
                r.start_date,
                r.end_date,
                r.type,
                r.status,
                r.source,
                r.reason,
                r.total_days,
                r.created_at
            FROM (
                SELECT 
                    id,
                    employee_id,
                    start_date,
                    end_date,
                    type,
                    status,
                    'leave' AS source,
                    reason,
                    total_days,
                    created_at
                FROM leaves
                WHERE status = 'Pending'
                AND manager_id = $1
                AND tenant_id = $2
                UNION ALL
                SELECT 
                    id,
                    employee_id,
                    start_date,
                    end_date,
                    type,
                    status,
                    'compoff' AS source,
                    reason,
                    NULL AS total_days,
                    created_at
                FROM attendance
                WHERE status = 'Pending'
                AND type = 'compoff'
                AND manager_id = $1
                AND tenant_id = $2
                UNION ALL
                SELECT 
                    id,
                    employee_id,
                    start_date,
                    end_date,
                    type,
                    status,
                    'attendance' AS source,
                    reason,
                    total_days,
                    created_at
                FROM attendance
                WHERE status = 'Pending'
                AND type = 'general attendance'
                AND manager_id = $1
                AND tenant_id = $2
            ) r
            JOIN employees e
            ON e.employee_id = r.employee_id
            ORDER BY r.start_date DESC
            `;
            const res = await client.query(query, [managerId, tenantId]);
            return createResponse(200, res.rows);
        }

        if (httpMethod === 'PUT') {
            console.log(JSON.parse(event.body));
            const { id, status, manager_notes, source, updated_at } = JSON.parse(event.body);
            await client.query('BEGIN');

            if (source === 'compoff') {
                // --- CASE A: Manager approves weekend work to EARN a comp-off ---
                const attRes = await client.query('SELECT employee_id, date FROM attendance WHERE id = $1 AND tenant_id = $2', [id, tenantId]);
                if (attRes.rows.length === 0) throw new Error("Attendance record not found");
                const { employee_id, date } = attRes.rows[0];

                if (status === 'Approved') {
                    const earned = new Date(date);
                    // Valid from: 1st of next month
                    const validFrom = new Date(earned.getFullYear(), earned.getMonth() + 1, 1);
                    // Expiry: Last day of 3rd month after earning (e.g., Earned Jan -> Valid Feb, Mar, Apr -> Expires Apr 30)
                    const expiry = new Date(earned.getFullYear(), earned.getMonth() + 4, 0);

                    const newEntry = {
                        comp_id: crypto.randomUUID(),
                        earned_date: date,
                        valid_from: validFrom.toISOString().split('T')[0],
                        expiry_date: expiry.toISOString().split('T')[0],
                        status: 'available',
                        leave_id: null
                    };

                    await client.query(
                        `UPDATE employees SET comp_off = COALESCE(comp_off, '[]'::jsonb) || $1::jsonb WHERE employee_id = $2`,
                        [JSON.stringify([newEntry]), employee_id]
                    );
                }
                let { leave_balance, comp_off } = empData.rows[0];
                comp_off = comp_off || [];

                // Find if a specific comp-off was reserved for this leave
                const linkedComp = comp_off.find(c => c.leave_id === id);

                if (status === 'Approved') {
                    if (linkedComp) linkedComp.status = 'used';
                } else if (status === 'Rejected' || status === 'Revoked') {
                    if (linkedComp) {
                        // Reflect back: restore this specific comp-off to available
                        linkedComp.status = 'available';
                        linkedComp.leave_id = null;
                    } else {
                        // Restore standard leave balance
                        leave_balance = (leave_balance || 0) + 1;
                    }
                }

                await client.query(
                    'UPDATE employees SET leave_balance = $1, comp_off = $2 WHERE employee_id = $3 AND tenant_id = $4',
                    [leave_balance, JSON.stringify(comp_off), employeeId, tenantId]
                );
                let dateField = status === 'Approved' ? 'approved_on' : (status === 'Rejected' ? 'rejected_on' : null);
                let dateValue = dateField ? new Date().toISOString().split('T')[0] : null;

                if (dateField) {
                    await client.query(
                        `UPDATE leaves SET status = $1, manager_notes = $2, updated_at = $4, ${dateField} = $6 WHERE id = $3 AND tenant_id = $5`,
                        [status, manager_notes, id, updated_at, tenantId, dateValue]
                    );
                } else {
                    await client.query(
                        'UPDATE leaves SET status = $1, manager_notes = $2, updated_at = $4 WHERE id = $3 AND tenant_id = $5',
                        [status, manager_notes, id, updated_at, tenantId]
                    );
                }
            } else if (source === 'attendance') {
                // --- CASE C: Manager approves/rejects a GENERAL ATTENDANCE regularization request ---
                let dateField = status === 'Approved' ? 'approved_on' : (status === 'Rejected' ? 'rejected_on' : null);
                let dateValue = dateField ? new Date().toISOString().split('T')[0] : null;

                if (dateField) {
                    await client.query(
                        `UPDATE attendance SET status = $1, manager_reason = $2, updated_at = $3, ${dateField} = $6 WHERE id = $4 AND tenant_id = $5`,
                        [status, manager_notes, updated_at, id, tenantId, dateValue]
                    );
                } else {
                    await client.query(
                        'UPDATE attendance SET status = $1, manager_reason = $2, updated_at = $3 WHERE id = $4 AND tenant_id = $5',
                        [status, manager_notes, updated_at, id, tenantId]
                    );
                }
            }

            await client.query('COMMIT');
            return createResponse(200, { message: "Action processed successfully." });
        }

        return createResponse(405, { message: "Method Not Allowed" });
    } catch (err) {
        if (client) await client.query('ROLLBACK');
        return createResponse(500, { error: err.message });
    } finally {
        if (client) client.release();
    }
};